export const FireBaseConfig = {
  apiKey: "AIzaSyATVdXer8Bx932Vl8erKxkHPsjlLvVAVGM",
  authDomain: "adminangular-5d21d.firebaseapp.com",
  projectId: "adminangular-5d21d",
  storageBucket: "adminangular-5d21d.appspot.com",
  messagingSenderId: "306203973432",
  appId: "1:306203973432:web:6d2cb9e9eab002fbfe93cd",
  measurementId: "G-K5T9T03P1K"

};
